

@extends('layout')

@section('content')



    {{--<link rel="stylesheet" href="{{asset('/css/style.css')}}">
    <script src="https://js.stripe.com/v3/"></script>
    <form action="{{url('charge')}}" method="post">
        <h3 style="color: white">
            Product name :- {{$product->name}}
        </h3>

        <label>
            <input name="cardholder-name" class="field is-empty" placeholder="Name" />
            <span><span>Name</span></span>
        </label>
        <label>
            <div id="card-element" class="field is-empty"></div>
            <span><span>Credit or debit card</span></span>
        </label>
        <button type="submit">Pay {{$product->price}}</button>
        <div class="outcome">
            <div class="error" role="alert"></div>
            <div class="success">
                Success! Your Stripe token is <span class="token"></span>
            </div>
        </div>
        {{csrf_field()}}
    </form>

    <script src="{{asset('/js/card.js')}}">
    </script>--}}

    <link rel="stylesheet" href="{{ asset('/css/style.css') }}" />
    <script src="https://js.stripe.com/v3/"></script>

    @if ($message = Session::get('success'))
        <div class="success">
            <strong>{{ $message }}</strong>
        </div>
    @endif


    @if ($message = Session::get('error'))
        <div class="error">
            <strong>{{ $message }}</strong>
        </div>
    @endif

    <form action="{{ url('charge') }}" method="post" id="payment-form">
        <div class="form-row">
            <p>Amount <input type="text" name="amount" placeholder="Enter Amount" value="{{$product->price}}"/></p>
            <p> Product Name <input type="text" name="name" placeholder="name" value="{{$product->name}}" /></p>
            <p> Name <input type="text" name="name" placeholder="Name" /></p>
            <input name="product_id" type="hidden" value="{{$product->product_id}}">
            <label for="card-element">
                Credit or debit card
            </label>
            <div id="card-element">
                <!-- A Stripe Element will be inserted here. -->
            </div>

            <!-- Used to display form errors. -->
            <div id="card-errors" role="alert"></div>
        </div>
        <p><button>Submit Payment</button></p>
        {{ csrf_field() }}
    </form>
    <script>
        var publishable_key = '{{ env('STRIPE_PUBLISHABLE_KEY') }}';
    </script>
    <script src="{{ asset('/js/card.js') }}"></script>
@endsection

